
# Futures Averaging Calculator

This is a simple web-based calculator for averaging down a futures position with leverage.

## How to deploy on GitHub Pages

1. Upload the files to a new GitHub repository.
2. Go to Repository > Settings > Pages.
3. Under "Source", select `main` branch and `/ (root)` folder.
4. Your site will be live at: `https://your-username.github.io/repository-name`
